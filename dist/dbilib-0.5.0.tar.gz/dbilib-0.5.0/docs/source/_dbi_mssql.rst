=========================================================
_dbi_mssql - Private database interface for MS SQL Server
=========================================================

.. automodule:: _dbi_mssql
