===================================================
_dbi_sqlite - Private database interface for SQLite
===================================================

.. automodule:: _dbi_sqlite
