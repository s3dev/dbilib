===================================================
_dbi_oracle - Private database interface for Oracle
===================================================

.. automodule:: _dbi_oracle
    :members:
    :undoc-members:
    :inherited-members:
    :private-members:
    :show-inheritance:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

