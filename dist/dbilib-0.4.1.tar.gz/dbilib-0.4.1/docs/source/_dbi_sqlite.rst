===================================================
_dbi_sqlite - Private database interface for SQLite
===================================================

.. automodule:: _dbi_sqlite
    :members:
    :undoc-members:
    :inherited-members:
    :private-members:
    :show-inheritance:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

