=============================================================
_dbi_mysql - Private database interface for MySQL and MariaDB
=============================================================

.. automodule:: _dbi_mysql
    :members:
    :undoc-members:
    :inherited-members:
    :private-members:
    :show-inheritance:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

