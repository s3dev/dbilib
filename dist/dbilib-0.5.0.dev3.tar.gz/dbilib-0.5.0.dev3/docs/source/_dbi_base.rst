============================================================
_dbi_base - Private base module for all database interfaces
============================================================

.. automodule:: _dbi_base
    :no-inherited-members:

