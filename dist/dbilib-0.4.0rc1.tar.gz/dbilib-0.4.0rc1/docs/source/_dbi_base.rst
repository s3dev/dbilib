============================================================
_dbi_base - Private base module for all database interfaces
============================================================

.. automodule:: _dbi_base
    :members:
    :undoc-members:
    :inherited-members:
    :private-members:
    :show-inheritance:
    :special-members:
    :exclude-members: __dict__, __module__, __weakref__

