=============================================================
_dbi_mysql - Private database interface for MySQL and MariaDB
=============================================================

.. automodule:: _dbi_mysql
