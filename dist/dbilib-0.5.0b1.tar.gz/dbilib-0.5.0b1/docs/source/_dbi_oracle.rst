===================================================
_dbi_oracle - Private database interface for Oracle
===================================================

.. automodule:: _dbi_oracle
