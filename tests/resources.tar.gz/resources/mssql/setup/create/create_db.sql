/*
    Purpose:    Primary database and user creation script.
    Author:     J. Berendt
    Date:       2025-07-14
    Revision:   1

    Updates:
    1:  Written.
*/

-- DROP/CREATE DATABASE
-- DROP DATABASE [dblib_test];
CREATE DATABASE [dbilib_test];
